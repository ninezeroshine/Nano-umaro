import React from 'react';

export function Sidebar() {
  return (
    <aside className="ng-sidebar">
      <div className="brand">
        <div className="logo">🧪</div>
        <div className="title">Nano Generator</div>
      </div>
      <nav className="nav">
        <a className="nav-item active">Генерация</a>
        <a className="nav-item" href="/">Базовый UI</a>
        <a className="nav-item" target="_blank" href="/README.md">Документация</a>
      </nav>
      <footer className="sidebar-footer">
        <small>Google Gemini 2.5 Flash Image (OpenRouter)</small>
      </footer>
    </aside>
  );
}


